
%How can you construct 1+...+10 with loop command

loop1=0;
for i=1:10
    loop1=loop1+i;
end




