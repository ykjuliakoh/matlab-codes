%Try to construct 2+4+6+...+20

